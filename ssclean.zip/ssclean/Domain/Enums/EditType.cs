﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.Enums
{
    public enum EditType
    {
        //การแก้ไข
        [Description("คงเดิม")]
        Unchange = 1,

        [Description("ปรับราคา")]
        PriceChange = 2 

    }
}
