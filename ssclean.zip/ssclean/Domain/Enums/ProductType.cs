﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.Enums
{
    public enum ProductType
    {

        //สินค้าและบริการ
        [Description("บริการ")]
        S = 1,

        [Description("สินค้า")]
        F = 2
    }
}
