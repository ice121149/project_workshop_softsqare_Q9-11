﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.Enums
{
    public enum TaxType
    {
        //ประเภทภาษี
        [Description("ไม่รวมภาษี")]
        TaxExclude = 1,

        [Description("รวมภาษี")]
        TaxInclude = 2
    }
}
