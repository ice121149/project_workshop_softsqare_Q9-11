# Clean
Clean architecture

frontend cd web/clientapp -> npm install -> npm start
backend: open Clean.sln and select Web project for startup project.
