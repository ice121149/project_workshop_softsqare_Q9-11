﻿using Domain.Entities.DB;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Persistense.Configurations.IN
{
    public class InGoodsConfigurations : BaseConfiguration<InGoods>
    {
        public override void Configure(EntityTypeBuilder<InGoods> builder)
        {
            base.Configure(builder);
            builder.ToTable("in_goods", "Back-End-Team");

            builder.HasKey(a => a.ItemId);
        }
    }
}
