﻿using Domain.Entities.DB;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Persistense.Configurations.QO
{
    public class QoSetupConfigurations: BaseConfiguration<QoSetup>
    {
        public override void Configure(EntityTypeBuilder<QoSetup> builder)
        {
            base.Configure(builder);
            builder.ToTable("qo_setup", "Back-End-Team");
            builder.HasKey(a => new { a.DataId });
            builder.HasAlternateKey(a => new { a.OuCode,a.PlType });
        }
    }
}
