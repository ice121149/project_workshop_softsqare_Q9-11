﻿using Application.Interfaces;
using Domain.Entities.DB;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Persistense
{
    public partial class CleanDbContext : DbContext, ICleanDbContext
    {
        public DbSet<QoPriceDetail> qoPriceDetail { get; set; }
        public DbSet<QoPriceMaster> qoPriceMaster { get; set; }
        public DbSet<QoSetup> qoSetups { get; set; }
    }
}
