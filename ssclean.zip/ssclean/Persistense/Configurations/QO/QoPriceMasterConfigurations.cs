﻿using Domain.Entities.DB;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Persistense.Configurations.QO
{
    public class QoPriceMasterConfigurations : BaseConfiguration<QoPriceMaster>
    {
        public override void Configure(EntityTypeBuilder<QoPriceMaster> builder)
        {
            base.Configure(builder);
            builder.ToTable("qo_price_master", "Back-End-Team");
            builder.HasKey(a => new { a.PlId });
            builder.HasAlternateKey(a => new { a.OuCode, a.PlCode } );
        }
    
    }
}
