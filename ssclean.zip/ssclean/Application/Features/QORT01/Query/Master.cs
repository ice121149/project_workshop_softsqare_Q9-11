﻿using Application.Common.Extensions;
using Application.Common.Models;
using Application.Interfaces;
using DocumentFormat.OpenXml.Office.CustomUI;
using Domain.Entities.DB;
using Domain.Enums;
using iText.Layout.Renderer;
using MediatR;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Application.Features.QORT01.Query
{
    public class Master
    {
        public class MasterData
        {
            public IEnumerable<dynamic> DDLCurrency { get; set; } //สลุลเงิน
            public IEnumerable<dynamic> DDLEditType { get; set; } //การแก้ไข
            public IEnumerable<dynamic> DDLPLType { get; set; } //แฟ้มราคา
            public IEnumerable<dynamic> DDLUnit { get; set; } //หน่วย
            public IEnumerable<dynamic> DDLPLCode { get; set; } //แฟ้มราคา
            public IEnumerable<dynamic> DDLGoodsService { get; set; } //สินค้าและบริการ


        }
        public class Query : IRequest<MasterData>
        {

        }

        public class Handler : IRequestHandler<Query, MasterData>
        {

            private readonly ICleanDbContext _context;
            public Handler(ICleanDbContext context)
            {
                _context = context;
            }



            public async Task<MasterData> Handle(Query request, CancellationToken cancellationToken)
            {
                MasterData masterData = new MasterData();
                masterData.DDLCurrency = await GetCurrency(cancellationToken);
                masterData.DDLEditType = await GetEditType(cancellationToken);
                masterData.DDLPLType = await GetPLType(cancellationToken);
                masterData.DDLUnit = await GetUnit(cancellationToken);

                masterData.DDLPLCode = await GetPLCode(cancellationToken);
                masterData.DDLGoodsService = await GetGoodsService(cancellationToken);


                return masterData;
            }


            private async Task<IEnumerable<dynamic>> GetCurrency(CancellationToken cancellationToken)
            {

                var result = await (from currency in _context.Set<DbCurrency>()
                                    where currency.Active == "Y" && currency.OuCode == "1001"
                                    orderby currency.CurNameTha
                                    select new DropDownDto
                                    {
                                        Value = currency.CurrCode,
                                        Text = currency.CurrCode + "-" + currency.CurNameTha,
                                    }
                                    ).ToListAsync(cancellationToken);

                return result;


            }


            private async Task<IEnumerable<dynamic>> GetEditType(CancellationToken cancellationToken)
            {
                var result = (from editType in Enum.GetValues(typeof(EditType)).Cast<EditType>()
                              orderby editType
                              select new DropDownDto
                              {
                                  Value = (int)editType == 1 ? "Unchanged" : "PriceChange",
                                  Value2 = (int)editType,
                                  Text = editType.GetDescription()
                              }).ToList();

                return result;

            }

            private async Task<IEnumerable<dynamic>> GetUnit(CancellationToken cancellationToken)
            {

                var result = await (from unit in _context.Set<DbUnit>()
                                    where unit.Active == "Y" && unit.OuCode == "1001"
                                    orderby unit.UnitName
                                    select new DropDownDto
                                    {
                                        Value = unit.UnitCode,
                                        Text = unit.UnitCode + "-" + unit.UnitCode,
                                    }
                                    ).ToListAsync(cancellationToken);

                return result;


            }


            private async Task<IEnumerable<dynamic>> GetPLType(CancellationToken cancellationToken)
            {

                var result = (from plType in Enum.GetValues(typeof(PLType)).Cast<PLType>()
                              orderby plType
                              select new DropDownDto
                              {
                                  Value = (int)plType == 1 ? "W" : "R",
                                  Value2 = (int)plType,
                                  Text = plType.GetDescription(),
                              }).ToList();

                return result;
            }

            private async Task<IEnumerable<dynamic>> GetPLCode(CancellationToken cancellationToken)
            {

                var result = await (from qoMaster in _context.Set<QoPriceMaster>()
                                    where qoMaster.OuCode == "1001"
                                    orderby qoMaster.PlNameTha
                                    select new DropDownDto
                                    {
                                        Value = qoMaster.PlCode,
                                        Value2 = qoMaster.PlId,
                                        Text = qoMaster.PlCode + " - " + qoMaster.PlNameTha,
                                    }
                                    ).ToListAsync(cancellationToken);

                return result;

            }


            private async Task<IEnumerable<dynamic>> GetGoodsService(CancellationToken cancellationToken)
            {
                var result1 = await (from service in _context.Set<IvServiceItem>()
                                     where service.OuCode == "1001"
                                     orderby service.ItemId
                                     select new DropDownDto
                                     {
                                         Value = service.ItemCode,
                                         Value2 = service.ItemId,
                                         Text = service.ItemCode + " - " + service.ItemName,
                                         Text2 = ProductType.S.GetDescription()
                                     }).ToListAsync(cancellationToken);


                var result2 = await (from goods in _context.Set<InGoods>()
                                     where goods.OuCode == "1001"
                                     orderby goods.ItemId
                                     select new DropDownDto
                                     {
                                         Value = goods.ItemCode,
                                         Value2 = goods.ItemId,
                                         Text = goods.ItemCode + " - " + goods.ItemName,
                                         Text2 = ProductType.F.GetDescription()
                                     }).ToListAsync(cancellationToken);



                var combineResult = result1.Concat(result2).ToList();

                return combineResult;
            }






        }

    }
}

