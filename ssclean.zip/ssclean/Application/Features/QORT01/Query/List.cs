﻿using Application.Common.Extensions;
using Application.Features.QORT01.DTO;
using Application.Interfaces;
using Domain.Entities.DB;
using Domain.Enums;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.WebSockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Application.Features.QORT01.Query
{
    public class List
    {
        public class Query : IRequest<List<QOMasterDTO>>
        {
            public string? Keywords { get; set; } //รหัสแฟ้ม , ชื่อแฟ้ม
            public PLType? PLTypeCode { get; set; } //รหัส ประเภทแฟ้มราาคา ชุดราคา
            public string? CurrCode { get; set; } ///รหัส สกุลเงิน
            public TaxType? TaxTypeCode { get; set; } //รหัส ประเภทภาษี
            public string? PLCode { get; set; } //รหัส แฟ้ม
        }

        public class Handler : IRequestHandler<Query, List<QOMasterDTO>>
        {
            private readonly ICleanDbContext _context;
            public Handler(ICleanDbContext context)
            {
                _context = context;
            }

            public async Task<List<QOMasterDTO>> Handle(Query request, CancellationToken cancellationToken)
            {
                var query = from qo in _context.Set<QoPriceMaster>()
                            join curr in _context.Set<DbCurrency>() on qo.CurrCode equals curr.CurrCode
                            where qo.OuCode == "1001"
                            orderby qo.PlNameTha
                            select new QOMasterDTO
                            {
                                PLId = qo.PlId,
                                PLTypeCode = qo.PlType == "W" ? PLType.W : PLType.R,
                                PLTypeName = qo.PlType == "W" ? PLType.W.GetDescription() : PLType.R.GetDescription(),
                                PLCode = qo.PlCode,
                                PLNameTH = qo.PlNameTha,
                                CuurencyCode = qo.CurrCode,
                                CurrencyName = qo.CurrCode + " - " + curr.CurNameTha,
                                TaxTypeCode = qo.VatType == "E" ? TaxType.TaxExclude : TaxType.TaxInclude,
                                TaxTypeName = qo.VatType == "E" ? TaxType.TaxExclude.GetDescription() : TaxType.TaxInclude.GetDescription()
                            };




                var keyword = request.Keywords?.Trim();
                
                if(!string.IsNullOrEmpty(keyword))
                {
                    query = query.Where(x => x.PLCode.Contains(keyword) || x.PLNameTH.Contains(keyword));
                }

                if(request.PLTypeCode != null)
                {
                    query = query.Where(x => x.PLTypeCode == request.PLTypeCode);
                }

                if(!string.IsNullOrEmpty(request.CurrCode))
                {
                    query = query.Where(x => x.CuurencyCode == request.CurrCode);
                }

                if (request.TaxTypeCode != null)
                {
                    query = query.Where(x => x.TaxTypeCode == request.TaxTypeCode);
                }

                if(!string.IsNullOrEmpty(request.PLCode))
                {
                    query = query.Where(x => x.PLCode == request.PLCode);
                }



                var result = query.ToList();

                return result;

            }
        }
    }
}
