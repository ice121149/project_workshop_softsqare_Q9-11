using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using Persistense.Provider;
using System.Threading.Tasks;

namespace Web;

public class Program
{
    public async static Task Main(string[] args)
    {
        IHost host = CreateHostBuilder(args)
            .ConfigureAppConfiguration((hostingContext, configuration) =>
            {
                configuration.AddCustomConfiguration();

                if (hostingContext.HostingEnvironment.IsDevelopment())
                {
                    configuration.AddJsonFile("appsettings.Development.json", optional: true, reloadOnChange: true);
                }
            })
            .Build();

        await host.RunAsync();
    }

    public static IHostBuilder CreateHostBuilder(string[] args) => Host.CreateDefaultBuilder(args).ConfigureWebHostDefaults(webBuilder => webBuilder.UseStartup<Startup>());
}
