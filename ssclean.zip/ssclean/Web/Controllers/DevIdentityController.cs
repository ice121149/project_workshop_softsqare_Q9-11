using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Security.Cryptography;

namespace Web.Controllers;

[AllowAnonymous]
[ApiController]
public class DevIdentityController : ControllerBase
{
    private const string ClientId = "ccs.spa";
    private const string ApiAudience = "ccs";
    private const string KeyId = "local-dev-key";
    private static readonly ConcurrentDictionary<string, AuthorizationCode> AuthorizationCodes = new();
    private static readonly RSA Rsa = RSA.Create(2048);
    private static readonly RsaSecurityKey SigningKey = new(Rsa) { KeyId = KeyId };
    private readonly IConfiguration _configuration;
    private readonly IWebHostEnvironment _environment;

    public DevIdentityController(IConfiguration configuration, IWebHostEnvironment environment)
    {
        _configuration = configuration;
        _environment = environment;
    }

    [HttpGet(".well-known/openid-configuration")]
    public IActionResult Discovery()
    {
        if (!IsEnabled()) return NotFound();

        string issuer = Issuer;

        return Ok(new
        {
            issuer,
            authorization_endpoint = $"{issuer}/connect/authorize",
            token_endpoint = $"{issuer}/connect/token",
            jwks_uri = $"{issuer}/connect/jwks",
            userinfo_endpoint = $"{issuer}/connect/userinfo",
            end_session_endpoint = $"{issuer}/connect/endsession",
            response_types_supported = new[] { "code" },
            grant_types_supported = new[] { "authorization_code" },
            subject_types_supported = new[] { "public" },
            id_token_signing_alg_values_supported = new[] { SecurityAlgorithms.RsaSha256 },
            scopes_supported = new[] { "openid", "profile", "ccs.resource.api", "ccs.content.api", "ccs.report.api" },
            claims_supported = DevClaims().Select(claim => claim.Type).Distinct().ToArray(),
            token_endpoint_auth_methods_supported = new[] { "none" },
            code_challenge_methods_supported = new[] { "S256" }
        });
    }

    [HttpGet("connect/jwks")]
    public IActionResult Jwks()
    {
        if (!IsEnabled()) return NotFound();

        RSAParameters parameters = Rsa.ExportParameters(false);

        return Ok(new
        {
            keys = new[]
            {
                new
                {
                    kty = "RSA",
                    use = "sig",
                    kid = KeyId,
                    alg = SecurityAlgorithms.RsaSha256,
                    e = Base64UrlEncoder.Encode(parameters.Exponent),
                    n = Base64UrlEncoder.Encode(parameters.Modulus)
                }
            }
        });
    }

    [HttpGet("connect/authorize")]
    public IActionResult Authorize(
        [FromQuery(Name = "client_id")] string clientId,
        [FromQuery(Name = "redirect_uri")] string redirectUri,
        [FromQuery(Name = "response_type")] string responseType,
        [FromQuery(Name = "scope")] string scope,
        [FromQuery(Name = "state")] string state,
        [FromQuery(Name = "nonce")] string nonce,
        [FromQuery(Name = "code_challenge")] string codeChallenge,
        [FromQuery(Name = "code_challenge_method")] string codeChallengeMethod)
    {
        if (!IsEnabled()) return NotFound();
        if (!IsValidAuthorizeRequest(clientId, redirectUri, responseType, codeChallenge, codeChallengeMethod))
        {
            return BadRequest("Invalid local development authorization request.");
        }

        string code = Base64UrlEncoder.Encode(RandomNumberGenerator.GetBytes(32));
        AuthorizationCodes[code] = new AuthorizationCode(
            redirectUri,
            nonce,
            codeChallenge,
            scope ?? "openid profile",
            DateTimeOffset.UtcNow.AddMinutes(5));

        string separator = redirectUri.Contains('?') ? "&" : "?";
        string stateValue = string.IsNullOrEmpty(state) ? string.Empty : $"&state={Uri.EscapeDataString(state)}";

        return Redirect($"{redirectUri}{separator}code={Uri.EscapeDataString(code)}{stateValue}");
    }

    [HttpPost("connect/token")]
    public IActionResult Token()
    {
        if (!IsEnabled()) return NotFound();

        IFormCollection form = Request.Form;
        string grantType = form["grant_type"];
        string code = form["code"];
        string redirectUri = form["redirect_uri"];
        string codeVerifier = form["code_verifier"];

        if (grantType != "authorization_code" ||
            !AuthorizationCodes.TryRemove(code, out AuthorizationCode authorizationCode) ||
            authorizationCode.ExpiresAt < DateTimeOffset.UtcNow ||
            authorizationCode.RedirectUri != redirectUri ||
            !ValidateCodeChallenge(authorizationCode.CodeChallenge, codeVerifier))
        {
            return BadRequest(new { error = "invalid_grant" });
        }

        DateTime now = DateTime.UtcNow;
        DateTime expires = now.AddHours(8);
        Claim[] claims = DevClaims().ToArray();

        string idToken = CreateToken(ClientId, claims, now, expires, authorizationCode.Nonce);
        string accessToken = CreateToken(ApiAudience, claims, now, expires);

        return Ok(new
        {
            access_token = accessToken,
            id_token = idToken,
            token_type = "Bearer",
            expires_in = (int)(expires - now).TotalSeconds,
            scope = authorizationCode.Scope
        });
    }

    [HttpGet("connect/userinfo")]
    public IActionResult UserInfo()
    {
        if (!IsEnabled()) return NotFound();

        return Ok(DevClaims()
            .GroupBy(claim => claim.Type)
            .ToDictionary(
                group => group.Key,
                group => group.Count() == 1 ? (object)group.Single().Value : group.Select(claim => claim.Value).ToArray()));
    }

    [HttpGet("connect/endsession")]
    public IActionResult EndSession([FromQuery(Name = "post_logout_redirect_uri")] string postLogoutRedirectUri)
    {
        if (!IsEnabled()) return NotFound();

        return Redirect(string.IsNullOrWhiteSpace(postLogoutRedirectUri) ? "http://localhost:4200" : postLogoutRedirectUri);
    }

    private string Issuer => (_configuration.GetValue<string>("Configuration:IdentityUrl") ?? "https://localhost:5001").TrimEnd('/');

    private bool IsEnabled() => _environment.IsDevelopment() && Issuer.Contains("localhost", StringComparison.OrdinalIgnoreCase);

    private static bool IsValidAuthorizeRequest(string clientId, string redirectUri, string responseType, string codeChallenge, string codeChallengeMethod)
    {
        return clientId == ClientId &&
            responseType == "code" &&
            !string.IsNullOrWhiteSpace(redirectUri) &&
            Uri.TryCreate(redirectUri, UriKind.Absolute, out Uri uri) &&
            uri.Host == "localhost" &&
            !string.IsNullOrWhiteSpace(codeChallenge) &&
            codeChallengeMethod == "S256";
    }

    private string CreateToken(string audience, IEnumerable<Claim> claims, DateTime issuedAt, DateTime expires, string nonce = null)
    {
        List<Claim> tokenClaims = claims.ToList();
        tokenClaims.Add(new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString("N")));
        tokenClaims.Add(new Claim("client_id", ClientId));

        if (!string.IsNullOrWhiteSpace(nonce))
        {
            tokenClaims.Add(new Claim(JwtRegisteredClaimNames.Nonce, nonce));
        }

        JwtSecurityToken token = new(
            issuer: Issuer,
            audience: audience,
            claims: tokenClaims,
            notBefore: issuedAt,
            expires: expires,
            signingCredentials: new SigningCredentials(SigningKey, SecurityAlgorithms.RsaSha256));

        return new JwtSecurityTokenHandler().WriteToken(token);
    }

    private static IEnumerable<Claim> DevClaims()
    {
        string[] roles =
        {
            "DBRT01", "DBRT02", "ETDT01", "ETRT01", "ETRT02", "SMRP01", "TMDT01",
            "SURT01", "SURT02", "SURT03", "SURT04", "SURT05", "SURT06", "SURT07", "SURT08",
            "Localize", "Menu", "Parameter", "Demo", "Setting",
            "formlayout", "input", "floatlabel", "invalidstate", "button", "table", "panel",
            "overlay", "message", "charts", "icons", "attachment"
        };

        yield return new Claim(JwtRegisteredClaimNames.Sub, "1");
        yield return new Claim(ClaimTypes.NameIdentifier, "1");
        yield return new Claim(JwtRegisteredClaimNames.Name, "Local Developer");
        yield return new Claim("preferred_username", "local_dev");
        yield return new Claim("Permission", "DEV");
        yield return new Claim("Ripple", "True");
        yield return new Claim("Inputstyle", "outlined");
        yield return new Claim("Menumode", "static");
        yield return new Claim("Scale", "14");
        yield return new Claim("Color", "#3B82F6");
        yield return new Claim("Colorscheme", "light");

        foreach (string role in roles)
        {
            yield return new Claim("role", role);
            yield return new Claim(ClaimTypes.Role, role);
        }
    }

    private static bool ValidateCodeChallenge(string codeChallenge, string codeVerifier)
    {
        if (string.IsNullOrWhiteSpace(codeChallenge) || string.IsNullOrWhiteSpace(codeVerifier))
        {
            return false;
        }

        byte[] hash = SHA256.HashData(System.Text.Encoding.ASCII.GetBytes(codeVerifier));
        string computedChallenge = Base64UrlEncoder.Encode(hash);

        return string.Equals(codeChallenge, computedChallenge, StringComparison.Ordinal);
    }

    private sealed record AuthorizationCode(
        string RedirectUri,
        string Nonce,
        string CodeChallenge,
        string Scope,
        DateTimeOffset ExpiresAt);
}
