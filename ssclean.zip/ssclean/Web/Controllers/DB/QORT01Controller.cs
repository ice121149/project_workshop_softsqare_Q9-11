﻿using Application.Features.QORT01;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace Web.Controllers.DB
{
    [AllowAnonymous]
    public class QORT01Controller  : BaseController
    {
        //[HttpGet("list")]
        //public async Task<ActionResult> List([FromQuery] List.Query query) => Ok(await Mediator.Send(query));        //[HttpGet("list")]
        
    }
}
